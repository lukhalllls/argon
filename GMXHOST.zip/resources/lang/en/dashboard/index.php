<?php

return [
    'search' => 'Busca de servidores...',
    'no_matches' => 'Não foram encontrados servidores que correspondessem aos critérios de busca fornecidos.',
    'cpu_title' => 'CPU',
    'memory_title' => 'Memória.',
];
